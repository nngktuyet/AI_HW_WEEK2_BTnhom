# FoodMood V19 Rename Patch

Changes made:

- Renamed visible app branding from FOODIFY/Foodify to FOODMOOD/FoodMood.
- Updated page titles, home screen logo text, README title, and app secret-key label.
- Kept fuzzy logic, map, cart, delivery fee, and no-kcal UI unchanged.

# PATCH NOTES - V18 No Kcal

Changes:
- Removed kcal/calories display from restaurant menu item cards.
- Kept the calories column in `data/menu.csv` only as raw dataset information, but it is no longer shown in the UI.
- No fuzzy logic or recommendation scoring was changed in this patch.

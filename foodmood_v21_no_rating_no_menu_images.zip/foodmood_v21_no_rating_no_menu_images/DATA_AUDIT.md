# Data audit V12

Source file: `AI_dataset_HW_week2 (2).xlsx`

## Exact fields rebuilt from Excel

- Restaurants: 68 rows from sheet `Quán`
- Menu items: 344 rows from sheet `Menu`
- Exact menu fields preserved: `Restaurant ID`, `Food-id`, `Tên món ăn`, `Giá`
- Exact restaurant fields preserved: `Restaurant ID`, `Tên Nhà Hàng`, `Tọa độ`, `Giá Trung Bình / Người`, `Meal type`, `Subcategory`, `Cuisine`, `Vege?`

## App helper fields

The Excel file does not contain rating/review/delivery-time columns, so the app keeps deterministic demo values for those fields only. These values are stable and do not overwrite the Excel fields.

## Suggestion mode

- `Bình thường`: does not filter out vegetarian food. It includes every available menu item.
- `Ăn chay`: keeps vegetarian restaurants/items only.
- Removed Dessert/Drink filter mode from the UI and code.

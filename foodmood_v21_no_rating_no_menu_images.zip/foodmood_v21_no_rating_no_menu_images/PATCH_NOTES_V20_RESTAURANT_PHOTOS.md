# PATCH NOTES V20 - Restaurant Photos

- Added real restaurant representative photos from the uploaded image package.
- Images are matched by restaurant_id, e.g. R001 -> /static/images/restaurants/R001.jpeg.
- Updated data/restaurants.csv image_path for all restaurants found in the uploaded package.
- Kept existing fuzzy logic, menu data, cart, checkout, delivery fee, and map route behavior unchanged.
- Added small CSS safeguards so restaurant images are cropped cleanly and card text does not overflow.

Matched images: 68
Missing restaurant IDs in uploaded image package: None

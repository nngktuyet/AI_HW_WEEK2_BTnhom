function money(v){ return Number(v).toLocaleString('vi-VN') + ' đ'; }
function bindRange(id, labelId, suffix='', formatter=null){
  const input=document.getElementById(id); const label=document.getElementById(labelId);
  if(!input || !label) return;
  const update=()=> label.textContent = formatter ? formatter(input.value) : `${input.value}${suffix}`;
  input.addEventListener('input', update); update();
}
bindRange('budget','budgetLabel','',money);
bindRange('hunger','hungerLabel','/10');
bindRange('timeAvailable','timeLabel',' phút');

const latEl = document.getElementById('userLat');
const lonEl = document.getElementById('userLon');
const weatherEl = document.getElementById('weather');
const weatherCodeEl = document.getElementById('weatherCode');
const weatherLabelHidden = document.getElementById('weatherLabelHidden');
const weatherIconHidden = document.getElementById('weatherIconHidden');
const sourceEl = document.getElementById('weatherSource');
const statusEl = document.getElementById('locationStatus');
const retryBtn = document.getElementById('retryLocation');
const weatherLabel = document.getElementById('weatherLabel');
const coordsChip = document.getElementById('coordsChip');

function weatherMeta(code, temp){
  const map = {
    0:['☀️','Nắng'], 1:['🌤️','Ít mây'], 2:['⛅','Có mây'], 3:['☁️','Nhiều mây'],
    45:['🌫️','Sương mù'], 48:['🌫️','Sương mù'],
    51:['🌦️','Mưa phùn nhẹ'], 53:['🌦️','Mưa phùn'], 55:['🌧️','Mưa phùn nặng'],
    61:['🌧️','Mưa nhẹ'], 63:['🌧️','Mưa'], 65:['⛈️','Mưa lớn'],
    80:['🌦️','Mưa rào nhẹ'], 81:['🌧️','Mưa rào'], 82:['⛈️','Mưa rào lớn'],
    95:['⛈️','Dông'], 96:['⛈️','Dông mưa đá'], 99:['⛈️','Dông mạnh']
  };
  let out = map[Number(code)] || ['🌡️','Thời tiết'];
  if((Number(code) === 0 || Number(code) === 1) && Number(temp) >= 32) out = ['☀️','Nắng nóng'];
  return {icon: out[0], label: out[1]};
}
function setStatus(text){ if(statusEl) statusEl.textContent = text; }
function setWeather(temp, source='auto', code=0){
  const rounded = Math.round(Number(temp));
  if(Number.isFinite(rounded)) {
    const meta = weatherMeta(code, rounded);
    weatherEl.value = rounded;
    weatherCodeEl.value = Number(code || 0);
    weatherLabelHidden.value = meta.label;
    weatherIconHidden.value = meta.icon;
    weatherLabel.textContent = `${meta.icon} ${meta.label} · ${rounded}°C`;
    sourceEl.value = source;
  }
}
function setCoords(lat, lon){
  latEl.value = Number(lat).toFixed(6);
  lonEl.value = Number(lon).toFixed(6);
  coordsChip.textContent = `GPS: ${Number(lat).toFixed(4)}, ${Number(lon).toFixed(4)}`;
}

let map, userMarker, userCircle;
function initMap(lat, lon){
  if(!window.L) return;
  if(!map){
    map = L.map('userMap', { zoomControl: false }).setView([lat, lon], 14);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: "" }).addTo(map);
  } else {
    map.setView([lat, lon], 14);
  }
  if(userMarker) userMarker.remove();
  if(userCircle) userCircle.remove();
  const userIcon = L.divIcon({ className: 'user-pin', html: '<div>📍</div>', iconSize: [36,36], iconAnchor: [18,32] });
  userMarker = L.marker([lat, lon], { icon: userIcon }).addTo(map).bindPopup('Vị trí của bạn').openPopup();
  userCircle = L.circle([lat, lon], { radius: 500, color: '#D86C9F', fillColor: '#FCE7F1', fillOpacity: 0.18, weight: 2 }).addTo(map);
  setTimeout(() => map.invalidateSize(), 100);
}

async function fetchWeather(lat, lon){
  try {
    weatherLabel.textContent = '🌡️ đang lấy...';
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,weather_code&timezone=auto`;
    const res = await fetch(url, { cache: 'no-store' });
    if(!res.ok) throw new Error('weather api failed');
    const data = await res.json();
    const temp = data?.current?.temperature_2m;
    const code = data?.current?.weather_code ?? 0;
    if(typeof temp !== 'number') throw new Error('missing temperature');
    setWeather(temp, 'open-meteo', code);
    const meta = weatherMeta(code, temp);
    setStatus(`Đã lấy GPS và thời tiết khu vực: ${meta.label}.`);
  } catch(err) {
    setWeather(weatherEl.value || 31, 'fallback', weatherCodeEl.value || 0);
    setStatus('Đã lấy vị trí. Không lấy được thời tiết online nên dùng dữ liệu mặc định.');
  }
}

function usePosition(lat, lon, isFallback=false){
  setCoords(lat, lon);
  initMap(lat, lon);
  if(isFallback){
    setStatus('Không có quyền GPS. App đang dùng vị trí mặc định ở TP.HCM.');
    setWeather(weatherEl.value || 31, 'fallback', 1);
  } else {
    fetchWeather(lat, lon);
  }
}

function getLocation(){
  if(!navigator.geolocation){
    usePosition(DEFAULT_LAT, DEFAULT_LON, true);
    return;
  }
  setStatus('Đang xin quyền định vị...');
  navigator.geolocation.getCurrentPosition((pos)=>{
    usePosition(pos.coords.latitude, pos.coords.longitude, false);
  }, ()=>{
    usePosition(DEFAULT_LAT, DEFAULT_LON, true);
  }, { enableHighAccuracy:true, timeout:9000, maximumAge:60000 });
}

if(retryBtn) retryBtn.addEventListener('click', getLocation);
usePosition(Number(latEl.value || DEFAULT_LAT), Number(lonEl.value || DEFAULT_LON), true);
getLocation();

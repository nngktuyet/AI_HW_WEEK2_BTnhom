# Rule audit - V12

## Dataset rebuild

Source files used:

- `AI_dataset_HW_week2 (2).xlsx`
- `rules-1.ipynb`

Rebuilt app data:

- `data/restaurants.csv`: 68 restaurants from sheet `Quán`
- `data/menu.csv`: 344 menu items from sheet `Menu`

Core fields copied from Excel:

- Restaurant: `Restaurant ID`, `Tên Nhà Hàng`, `Tọa độ`, `Giá Trung Bình / Người`, `Meal type`, `Subcategory 1`, `Vege?`
- Menu: `Restaurant ID`, `Food-id`, `Tên món ăn`, `Giá`

The app parses restaurant coordinates and price ranges directly from the new workbook. Menu prices are taken from the `Giá` column, not from restaurant average price.

## UI changes

Health goal now has only the three rule-supported choices:

- Giảm cân → `diet`
- Cân bằng → `balanced`
- Tăng cơ → `bulking`

Suggestion mode is separate from health goal and now has only two choices:

- Bình thường: includes every menu item, including vegetarian food.
- Ăn chay: filters vegetarian restaurants/items only.

The old Dessert/Drink suggestion-mode buttons were removed from the UI and filtering logic.

## Rule implementation

`rules-1.ipynb` defines fuzzy inputs:

- `budget`
- `hunger`
- `time_available`
- `weather`
- `health_goal`

Fuzzy outputs:

- `preferred_price`
- `preferred_meal`
- `preferred_distance`

The app implements the new output meal labels:

- `fastfood`
- `snacks`
- `healthy`
- `vegetarian`
- `fullmeal`

Final fuzzy score follows the notebook weights:

```text
final_score = price_match * 0.3 + meal_match * 0.5 + distance_match * 0.2
```

## Matching logic

`preferred_price` is matched against each menu item price.

`preferred_meal` is matched against the item's normalized meal category, derived from the restaurant subcategory and item name where needed.

`preferred_distance` is matched against estimated road distance, not straight-line distance.

Restaurant ranking groups menu items by restaurant and uses the best matching item as the main representative for that restaurant.

## Removed from app logic

The recommendation code no longer uses cuisine selection or spicy-level inputs. They are not present in the UI and do not affect scoring.

from __future__ import annotations

import csv
import math
import os
import time
from dataclasses import dataclass
from typing import Dict, List, Any
from flask import Flask, jsonify, redirect, render_template, request, session, url_for

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "foodmood-fuzzy-demo")
BASE_DIR = os.path.dirname(__file__)
RESTAURANT_CSV = os.path.join(BASE_DIR, "data", "restaurants.csv")
MENU_CSV = os.path.join(BASE_DIR, "data", "menu.csv")
DEFAULT_LAT = 10.7625
DEFAULT_LON = 106.6820


def as_float(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def as_int(value: Any, default: int = 0) -> int:
    try:
        return int(float(value))
    except Exception:
        return default


def read_csv(path: str) -> List[Dict[str, Any]]:
    with open(path, encoding="utf-8") as f:
        return [dict(row) for row in csv.DictReader(f)]


def load_data() -> tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    restaurants = read_csv(RESTAURANT_CSV)
    menu = read_csv(MENU_CSV)
    for r in restaurants:
        r["lat"] = as_float(r["lat"])
        r["lon"] = as_float(r["lon"])
        r["avg_price"] = as_int(r["avg_price"])
        r["price_min"] = as_int(r["price_min"])
        r["price_max"] = as_int(r["price_max"])
        r["rating"] = as_float(r["rating"], 4.4)
        r["reviews"] = as_int(r["reviews"])
        r["delivery_fee"] = as_int(r["delivery_fee"])
        r["delivery_time_min"] = as_int(r["delivery_time_min"])
        r["delivery_time_max"] = as_int(r["delivery_time_max"])
    by_id = {r["restaurant_id"]: r for r in restaurants}
    for m in menu:
        m["price"] = as_int(m["price"])
        m["calories"] = as_int(m["calories"])
        m["is_hot_food"] = str(m.get("is_hot_food", "")).lower() == "true"
        m["is_vegetarian"] = str(m.get("is_vegetarian", "")).lower() == "true"
        m["meal_category"] = str(m.get("meal_category") or m.get("meal_type") or "fullmeal").lower()
        m["restaurant"] = by_id.get(m["restaurant_id"])
    return restaurants, menu


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    radius = 6371.0
    p1 = math.radians(lat1)
    p2 = math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return radius * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def estimate_road_distance_km(straight_km: float) -> float:
    """Offline heuristic for road distance in city streets.

    The UI still tries to fetch a real OSRM road route. This heuristic is used for
    ranking/ETA before the browser route API returns, so we never rank by raw bird-flight distance only.
    """
    if straight_km <= 1:
        factor = 1.45
    elif straight_km <= 4:
        factor = 1.32
    else:
        factor = 1.22
    return round(max(straight_km * factor, straight_km + 0.25), 2)


def estimate_delivery_eta(prep_min: int, road_km: float, weather_code: int = 0) -> int:
    traffic_buffer = 6 if road_km >= 3 else 4
    weather_buffer = 0
    if 51 <= weather_code <= 67 or 80 <= weather_code <= 82 or 95 <= weather_code <= 99:
        weather_buffer = 8
    elif weather_code in [45, 48]:
        weather_buffer = 4
    return int(round(prep_min + road_km * 5 + traffic_buffer + weather_buffer))


def delivery_fuzzy_profile(distance_km: float, weather_temp: int) -> Dict[str, Any]:
    """Delivery fee/time Mamdani rules aligned with Money.ipynb."""
    d = max(0.0, min(float(distance_km), 20.0))
    w = max(15.0, min(float(weather_temp), 45.0))

    dist = {
        "near": trapmf(d, 0, 0, 1, 3),
        "medium": trimf(d, 2, 5, 8),
        "far": trapmf(d, 6, 10, 20, 20),
    }
    temp = {
        "cold": trapmf(w, 15, 15, 18, 23),
        "normal": trimf(w, 22, 27, 32),
        "hot": trapmf(w, 30, 35, 45, 45),
    }

    fee_rule = {"cheap": 0.0, "medium": 0.0, "expensive": 0.0}
    time_rule = {"fast": 0.0, "normal": 0.0, "slow": 0.0}

    # Money.ipynb rules 1..16
    fee_rule["cheap"] = max(fee_rule["cheap"], dist["near"])
    fee_rule["medium"] = max(fee_rule["medium"], dist["medium"])
    fee_rule["expensive"] = max(fee_rule["expensive"], dist["far"])
    time_rule["fast"] = max(time_rule["fast"], dist["near"])
    time_rule["normal"] = max(time_rule["normal"], dist["medium"])
    time_rule["slow"] = max(time_rule["slow"], dist["far"])

    hot_far = min(temp["hot"], dist["far"])
    cold_near = min(temp["cold"], dist["near"])
    normal_medium = min(temp["normal"], dist["medium"])
    hot_medium = min(temp["hot"], dist["medium"])
    cold_far = min(temp["cold"], dist["far"])
    fee_rule["expensive"] = max(fee_rule["expensive"], hot_far)
    time_rule["slow"] = max(time_rule["slow"], hot_far)
    fee_rule["cheap"] = max(fee_rule["cheap"], cold_near)
    time_rule["fast"] = max(time_rule["fast"], cold_near)
    fee_rule["medium"] = max(fee_rule["medium"], normal_medium, hot_medium, cold_far)
    time_rule["normal"] = max(time_rule["normal"], normal_medium, hot_medium)
    time_rule["slow"] = max(time_rule["slow"], cold_far)

    fee_mf = {
        "cheap": lambda x: trapmf(x, 0, 0, 10000, 20000),
        "medium": lambda x: trimf(x, 15000, 30000, 50000),
        "expensive": lambda x: trapmf(x, 45000, 60000, 100000, 100000),
    }
    time_mf = {
        "fast": lambda x: trapmf(x, 0, 0, 10, 17),
        "normal": lambda x: trimf(x, 15, 25, 35),
        "slow": lambda x: trapmf(x, 30, 40, 60, 60),
    }
    fee = mamdani_centroid(fee_rule, fee_mf, range(0, 100001, 1000), fallback=25000)
    delivery_minutes = mamdani_centroid(time_rule, time_mf, range(0, 91, 1), fallback=30)

    return {
        "delivery_fee": int(round(fee / 1000) * 1000),
        "delivery_time": int(round(delivery_minutes)),
        "delivery_fee_label": max(fee_rule, key=fee_rule.get),
        "delivery_time_label": max(time_rule, key=time_rule.get),
    }

def clamp(value: float, low: float = 0, high: float = 100) -> float:
    return max(low, min(high, value))


def trimf(x: float, a: float, b: float, c: float) -> float:
    if x <= a or x >= c:
        return 0.0
    if x == b:
        return 1.0
    if x < b:
        return (x - a) / (b - a)
    return (c - x) / (c - b)


def trapmf(x: float, a: float, b: float, c: float, d: float) -> float:
    """Trapezoid membership with correct shoulder behavior.

    This matches scikit-fuzzy trapmf semantics better than the previous version.
    It fixes endpoints such as hunger=1 for [1,1,3,5] and budget=1000000 for
    [400000,700000,1000000,1000000].
    """
    x = float(x)
    if a == b and x <= b:
        return 1.0
    if c == d and x >= c:
        return 1.0
    if x <= a or x >= d:
        return 0.0
    if b <= x <= c:
        return 1.0
    if a < x < b:
        return (x - a) / (b - a) if b != a else 1.0
    if c < x < d:
        return (d - x) / (d - c) if d != c else 1.0
    return 0.0


def weighted_center(scores: Dict[str, float], centers: Dict[str, float], fallback: float = 60) -> float:
    total = sum(scores.values())
    if total <= 0:
        return fallback
    return sum(scores[k] * centers[k] for k in scores) / total


def mamdani_centroid(label_strengths: Dict[str, float], membership_functions: Dict[str, Any], universe: range, fallback: float) -> float:
    """Defuzzify with max-min aggregation + centroid, matching scikit-fuzzy style more closely."""
    numerator = 0.0
    denominator = 0.0
    for x in universe:
        mu = 0.0
        for label, strength in label_strengths.items():
            if strength <= 0:
                continue
            mu = max(mu, min(float(strength), float(membership_functions[label](x))))
        numerator += x * mu
        denominator += mu
    if denominator <= 0:
        return fallback
    return numerator / denominator


def health_goal_value(health_goal: str) -> float:
    """Map UI choices to the numeric health_goal universe used in rules-1.ipynb.

    The new UI keeps only three health goals:
    - diet / giảm cân -> 2
    - balanced / cân bằng -> 4
    - bulking / tăng cơ -> 8
    """
    mapping = {"diet": 2, "balanced": 4, "bulking": 8}
    return float(mapping.get(health_goal, 4))


def meal_label_vi(label: str) -> str:
    return {
        "fastfood": "FastFood",
        "snacks": "Snacks",
        "desserts": "Dessert",
        "drink": "Drink",
        "healthy": "Healthy",
        "vegetarian": "Ăn chay",
        "fullmeal": "FullMeal",
    }.get(label, label)


def suggestion_filter_label(value: str) -> str:
    return {
        "normal": "Bình thường",
        "vegetarian": "Ăn chay",
    }.get(value, "Bình thường")


def fuzzy_profile(budget: int, hunger: int, time_available: int, weather: int, health_goal: str) -> Dict[str, Any]:
    """Mamdani fuzzy inference aligned with uploaded rules-1.ipynb.

    Inputs: budget, hunger, time_available, weather, health_goal.
    Outputs: preferred_price, preferred_meal, preferred_distance.
    """
    health_value = health_goal_value(health_goal)

    b = {
        "very_cheap": trapmf(budget, 0, 0, 20000, 50000),
        "cheap": trimf(budget, 50000, 80000, 120000),
        "medium": trimf(budget, 100000, 200000, 300000),
        "expensive": trapmf(budget, 280000, 500000, 1000000, 1000000),
    }
    h = {
        "light": trimf(hunger, 1, 3, 5),
        "hungry": trimf(hunger, 4, 6, 8),
        "starving": trapmf(hunger, 7, 8, 10, 10),
    }
    t = {
        "very_short": trapmf(time_available, 0, 0, 10, 20),
        "short": trimf(time_available, 15, 30, 45),
        "medium": trimf(time_available, 40, 70, 100),
        "long": trapmf(time_available, 90, 120, 180, 180),
    }
    w = {
        "cold": trapmf(weather, 15, 15, 18, 23),
        "normal": trimf(weather, 22, 27, 32),
        "hot": trapmf(weather, 30, 35, 45, 45),
    }
    g = {
        "diet": trapmf(health_value, 1, 1, 2, 3),
        "balanced": trimf(health_value, 2.5, 4, 6),
        "bulking": trapmf(health_value, 6, 8, 10, 10),
    }

    price_pref = {"cheap": 0.0, "medium": 0.0, "expensive": 0.0}
    meal_pref = {"fastfood": 0.0, "snacks": 0.0, "desserts": 0.0, "drink": 0.0, "healthy": 0.0, "vegetarian": 0.0, "fullmeal": 0.0}
    distance_pref = {"near": 0.0, "medium": 0.0, "far": 0.0}

    # PRICE PREFERENCE RULES: rules 1-4, 78-89
    price_pref["cheap"] = max(price_pref["cheap"], b["very_cheap"], b["cheap"])
    price_pref["medium"] = max(price_pref["medium"], b["medium"])
    price_pref["expensive"] = max(price_pref["expensive"], b["expensive"])
    price_pref["cheap"] = max(price_pref["cheap"], min(b["very_cheap"], h["light"]), min(b["very_cheap"], h["hungry"]), min(b["very_cheap"], h["starving"]), min(b["cheap"], h["light"]), min(b["cheap"], h["hungry"]))
    price_pref["medium"] = max(price_pref["medium"], min(b["cheap"], h["starving"]), min(b["medium"], h["light"]), min(b["medium"], h["hungry"]))
    price_pref["expensive"] = max(price_pref["expensive"], min(b["medium"], h["starving"]), min(b["expensive"], h["light"]), min(b["expensive"], h["hungry"]), min(b["expensive"], h["starving"]))

    # HUNGER x TIME RULES: rules 5-16
    meal_pref["drink"] = max(meal_pref["drink"], min(h["light"], t["very_short"]))
    meal_pref["snacks"] = max(meal_pref["snacks"], min(h["light"], t["short"]), min(h["hungry"], t["very_short"]), min(h["hungry"], t["short"]))
    meal_pref["desserts"] = max(meal_pref["desserts"], min(h["light"], t["medium"]), min(h["light"], t["long"]))
    meal_pref["healthy"] = max(meal_pref["healthy"], min(h["hungry"], t["medium"]))
    meal_pref["fullmeal"] = max(meal_pref["fullmeal"], min(h["hungry"], t["long"]), min(h["starving"], t["medium"]), min(h["starving"], t["long"]))
    meal_pref["fastfood"] = max(meal_pref["fastfood"], min(h["starving"], t["very_short"]), min(h["starving"], t["short"]))

    # BUDGET x HEALTH RULES: rules 17-28
    meal_pref["vegetarian"] = max(meal_pref["vegetarian"], min(b["very_cheap"], g["diet"]))
    meal_pref["fullmeal"] = max(meal_pref["fullmeal"], min(b["very_cheap"], g["balanced"]), min(b["cheap"], g["diet"]), min(b["medium"], g["bulking"]), min(b["expensive"], g["balanced"]), min(b["expensive"], g["bulking"]))
    meal_pref["fastfood"] = max(meal_pref["fastfood"], min(b["very_cheap"], g["bulking"]), min(b["cheap"], g["bulking"]))
    meal_pref["healthy"] = max(meal_pref["healthy"], min(b["cheap"], g["balanced"]), min(b["medium"], g["diet"]), min(b["medium"], g["balanced"]), min(b["expensive"], g["diet"]))

    # MEAL PREFERENCE RULES: rules 29-56, 66-77
    meal_pref["fastfood"] = max(meal_pref["fastfood"], min(h["starving"], b["very_cheap"]), min(h["starving"], b["cheap"]), min(h["hungry"], b["cheap"]), min(w["hot"], h["starving"]), min(w["hot"], h["starving"], t["short"]), min(b["very_cheap"], h["hungry"]), min(b["very_cheap"], h["starving"]), min(b["cheap"], h["hungry"]), min(b["cheap"], h["starving"]))
    meal_pref["fullmeal"] = max(
        meal_pref["fullmeal"],
        min(h["starving"], b["medium"]),
        min(h["starving"], b["expensive"]),
        min(h["hungry"], b["expensive"]),
        min(w["cold"], h["hungry"]),
        min(w["cold"], h["starving"]),
        min(w["normal"], h["starving"]),
        min(g["balanced"], h["hungry"]),
        min(g["balanced"], h["starving"]),
        g["bulking"],
        min(w["cold"], h["starving"], t["long"]),
        min(b["medium"], h["starving"]),
        min(b["expensive"], h["starving"]),
    )
    meal_pref["healthy"] = max(
        meal_pref["healthy"],
        min(h["hungry"], b["medium"]),
        min(w["normal"], h["hungry"]),
        g["diet"],
        # Balanced should not automatically force healthy.
        # It becomes healthy mainly when hunger is light or time is comfortable.
        min(g["balanced"], h["light"]),
        min(g["balanced"], h["hungry"], t["medium"]),
        min(b["medium"], h["hungry"]),
        min(b["expensive"], h["hungry"]),
    )
    meal_pref["drink"] = max(meal_pref["drink"], min(w["hot"], h["light"]), min(g["bulking"], w["hot"]), min(w["hot"], t["very_short"]), min(w["hot"], h["light"], t["very_short"]))
    meal_pref["desserts"] = max(meal_pref["desserts"], min(w["hot"], h["hungry"]), min(w["normal"], h["light"]), min(w["hot"], t["short"]), min(b["medium"], h["light"]), min(b["expensive"], h["light"]))
    meal_pref["snacks"] = max(meal_pref["snacks"], min(w["cold"], h["light"]), min(b["very_cheap"], h["light"]), min(b["cheap"], h["light"]))
    meal_pref["vegetarian"] = max(meal_pref["vegetarian"], min(g["diet"], w["hot"]), min(g["diet"], h["light"]))

    # DISTANCE PREFERENCE RULES: rules 57-65, 90-101
    distance_pref["near"] = max(distance_pref["near"], t["very_short"], t["short"], min(h["starving"], t["very_short"]), w["hot"], min(b["very_cheap"], h["light"]), min(b["very_cheap"], h["hungry"]), min(b["very_cheap"], h["starving"]), min(b["cheap"], h["light"]), min(b["cheap"], h["starving"]))
    distance_pref["medium"] = max(distance_pref["medium"], t["medium"], min(w["normal"], t["medium"]), min(b["cheap"], h["hungry"]), min(b["medium"], h["light"]), min(b["medium"], h["hungry"]), min(b["medium"], h["starving"]))
    distance_pref["far"] = max(distance_pref["far"], t["long"], min(t["long"], b["expensive"]), min(w["cold"], t["long"]), min(b["expensive"], h["light"]), min(b["expensive"], h["hungry"]), min(b["expensive"], h["starving"]))

    price_mf = {
        "cheap": lambda x: trapmf(x, 0, 0, 25, 50),
        "medium": lambda x: trimf(x, 40, 60, 80),
        "expensive": lambda x: trapmf(x, 70, 85, 100, 100),
    }
    meal_mf = {
        "fastfood": lambda x: trimf(x, 0, 14, 28),
        "snacks": lambda x: trimf(x, 14, 28, 42),
        "desserts": lambda x: trimf(x, 28, 42, 56),
        "drink": lambda x: trimf(x, 42, 56, 70),
        "healthy": lambda x: trimf(x, 56, 70, 84),
        "vegetarian": lambda x: trimf(x, 70, 84, 98),
        "fullmeal": lambda x: trimf(x, 84, 98, 100),
    }
    distance_mf = {
        "near": lambda x: trapmf(x, 0, 0, 25, 50),
        "medium": lambda x: trimf(x, 40, 60, 80),
        "far": lambda x: trapmf(x, 70, 85, 100, 100),
    }
    price_score = mamdani_centroid(price_pref, price_mf, range(0, 101), fallback=35)
    meal_score = mamdani_centroid(meal_pref, meal_mf, range(0, 101), fallback=70)
    distance_score = mamdani_centroid(distance_pref, distance_mf, range(0, 101), fallback=35)
    meal_label = max(meal_pref, key=meal_pref.get)

    return {
        "preferred_price_score": price_score,
        "preferred_meal_score": meal_score,
        "preferred_distance_score": distance_score,
        "price_label": max(price_pref, key=price_pref.get),
        "meal_label": meal_label,
        "meal_label_vi": meal_label_vi(meal_label),
        "distance_label": max(distance_pref, key=distance_pref.get),
        "health_goal": health_goal,
        "health_value": health_value,
        "weather": weather,
        "rule_strengths": {"price": price_pref, "meal": meal_pref, "distance": distance_pref},
    }

def restaurant_price_range_score(price_min: int, price_max: int, user_budget: int) -> float:
    """Budget fit from uploaded rule notebook's price_score(range_price, user_budget).

    The dataset used by the app stores restaurant price_min/price_max separately,
    so this is the same idea without parsing a string like "100.000-200.000".
    """
    low = float(price_min)
    high = float(price_max)
    if high <= 0:
        return 50.0
    if low <= user_budget <= high:
        return 100.0
    center = (low + high) / 2
    diff = abs(float(user_budget) - center)
    return float(max(0, 100 - (diff / (high + 1)) * 100))


def price_band_score(price: int) -> int:
    if price <= 120000:
        return 25
    if price <= 300000:
        return 60
    return 85


def normalize_meal_category(meal_category: str) -> str:
    """Normalize dataset/UI meal labels before matching against fuzzy rule strengths."""
    cat = str(meal_category or "fullmeal").strip().lower()
    aliases = {
        "fast food": "fastfood",
        "fast_food": "fastfood",
        "full meal": "fullmeal",
        "full_meal": "fullmeal",
        "healthy meal": "healthy",
        "healthymeal": "healthy",
        "lightmeal": "snacks",
        "light meal": "snacks",
        "snack": "snacks",
        "dessert": "desserts",
        "drinks": "drink",
        "beverage": "drink",
    }
    return aliases.get(cat, cat)


def meal_match_score(profile: Dict[str, Any], meal_category: str, hunger: int) -> float:
    """Match a menu item category using direct fuzzy rule activation.

    Meal type is categorical, not a continuous scale. Therefore, unlike price
    and distance, it should not be scored by checking where a centroid lands on
    a fake 0-100 meal axis. This prevents unrelated categories such as drink
    from winning only because they sit numerically between other meal labels.
    """
    cat = normalize_meal_category(meal_category)
    strengths = profile.get("rule_strengths", {}).get("meal", {})
    if not strengths:
        return 0.0

    max_strength = max(float(v) for v in strengths.values())
    if max_strength <= 0:
        return 0.0

    score = float(strengths.get(cat, 0.0)) / max_strength * 100

    # Practical guardrails so the app feels human, not only mathematically fuzzy.
    # Very hungry users should not mainly get drinks/desserts/snacks.
    if hunger >= 8 and cat == "drink":
        score = min(score, 20)
    if hunger >= 8 and cat in ["desserts", "snacks"]:
        score = min(score, 35)

    # Light hunger should not be pushed too strongly toward heavy meals.
    if hunger <= 3 and cat in ["fullmeal", "fastfood"]:
        score = min(score, 45)

    return clamp(score)


def meal_band_score(meal_type: str) -> int:
    return {"fastfood": 14, "snacks": 28, "desserts": 42, "drink": 56, "healthy": 70, "vegetarian": 84, "fullmeal": 98}.get(str(meal_type).lower(), 98)


def passes_suggestion_filter(item: Dict[str, Any], category_filter: str) -> bool:
    """Suggestion mode filter.

    - normal: includes every menu item, including vegetarian food.
    - vegetarian: keeps vegetarian restaurants/items only.
    """
    if category_filter == "vegetarian":
        cat = str(item.get("meal_category") or item.get("meal_type") or "fullmeal").lower()
        name = str(item.get("food_name") or "").lower()
        is_veg = str(item.get("is_vegetarian", "")).lower() == "true"
        return is_veg or cat == "vegetarian" or "chay" in name
    return True


def distance_band_score(distance_km: float) -> int:
    if distance_km <= 1.5:
        return 20
    if distance_km <= 5:
        return 60
    return 90


def weather_meta(code: int, temp: int) -> Dict[str, str]:
    mapping = {
        0: ("☀️", "Nắng"),
        1: ("🌤️", "Ít mây"),
        2: ("⛅", "Có mây"),
        3: ("☁️", "Nhiều mây"),
        45: ("🌫️", "Sương mù"),
        48: ("🌫️", "Sương mù đóng băng"),
        51: ("🌦️", "Mưa phùn nhẹ"),
        53: ("🌦️", "Mưa phùn"),
        55: ("🌧️", "Mưa phùn nặng"),
        61: ("🌧️", "Mưa nhẹ"),
        63: ("🌧️", "Mưa"),
        65: ("⛈️", "Mưa lớn"),
        80: ("🌦️", "Mưa rào nhẹ"),
        81: ("🌧️", "Mưa rào"),
        82: ("⛈️", "Mưa rào lớn"),
        95: ("⛈️", "Dông"),
        96: ("⛈️", "Dông kèm mưa đá"),
        99: ("⛈️", "Dông mạnh"),
    }
    icon, label = mapping.get(code, ("🌡️", "Thời tiết"))
    if code in [0, 1] and temp >= 32:
        icon, label = "☀️", "Nắng nóng"
    return {"icon": icon, "label": label}


def explain(scores: Dict[str, float], item: Dict[str, Any], restaurant: Dict[str, Any], distance_km: float) -> List[str]:
    reasons = []
    if scores["price_match"] >= 80:
        reasons.append("giá hợp ngân sách")
    if scores["meal_match"] >= 80:
        reasons.append("đúng kiểu bữa ăn")
    if scores["distance_match"] >= 80 or distance_km <= 2:
        reasons.append("gần vị trí của bạn")
    if item.get("is_hot_food"):
        reasons.append("món nóng, dễ ăn")
    return reasons[:4] or ["điểm fuzzy tổng thể cao"]


def recommend(form: Dict[str, Any]) -> tuple[List[Dict[str, Any]], Dict[str, Any]]:
    restaurants, menu = load_data()
    user_lat = as_float(form.get("user_lat"), DEFAULT_LAT)
    user_lon = as_float(form.get("user_lon"), DEFAULT_LON)
    budget = as_int(form.get("budget"), 60000)
    hunger = as_int(form.get("hunger"), 6)
    time_available = as_int(form.get("time_available"), 45)
    weather = as_int(form.get("weather"), 31)
    weather_code = as_int(form.get("weather_code"), 0)
    health_goal = form.get("health_goal", "balanced")
    category_filter = form.get("category_filter", "normal")

    profile = fuzzy_profile(budget, hunger, time_available, weather, health_goal)
    by_id = {r["restaurant_id"]: r for r in restaurants}
    results = []
    for item in menu:
        restaurant = by_id.get(item["restaurant_id"])
        if not restaurant:
            continue
        # Suggestion mode from the input screen.
        if not passes_suggestion_filter(item, category_filter):
            continue

        # Budget is fuzzy, but the app still needs a realistic spending guardrail.
        # Slightly over budget can still appear; far over budget is removed.
        price = as_int(item.get("price"), 0)
        safe_budget = max(budget, 1)
        if price > safe_budget * 1.5:
            continue

        straight_km = haversine_km(user_lat, user_lon, restaurant["lat"], restaurant["lon"])
        road_km = estimate_road_distance_km(straight_km)
        delivery_rule = delivery_fuzzy_profile(road_km, weather)
        eta = max(restaurant["delivery_time_min"], delivery_rule["delivery_time"])
        distance_km = road_km

        # Budget remains fuzzy. We compare the fuzzy preferred_price output with the
        # item price band, then blend in the restaurant price-range fit from the
        # uploaded notebook's price_score(range_price, user_budget).
        item_price_match = clamp(100 - abs(profile["preferred_price_score"] - price_band_score(item["price"])))
        restaurant_budget_match = restaurant_price_range_score(restaurant["price_min"], restaurant["price_max"], budget)

        scores = {
            "price_match": clamp(item_price_match * 0.65 + restaurant_budget_match * 0.35),
            "meal_match": meal_match_score(profile, item.get("meal_category") or item.get("meal_type"), hunger),
            "distance_match": clamp(100 - abs(profile["preferred_distance_score"] - distance_band_score(distance_km))),
        }

        # If the item is only slightly over budget, keep it but weaken price fit.
        if price > safe_budget * 1.2:
            scores["price_match"] *= 0.45

        # Rating/quán đạt chuẩn is handled only after grouping by restaurant.
        # Main fuzzy score follows rules-1.ipynb final weights: price 0.3, meal 0.5, distance 0.2.
        final_score = (
            scores["price_match"] * 0.30
            + scores["meal_match"] * 0.50
            + scores["distance_match"] * 0.20
        )
        row = {
            **item,
            "restaurant_name": restaurant["restaurant_name"],
            "lat": restaurant["lat"],
            "lon": restaurant["lon"],
            "rating": restaurant["rating"],
            "reviews": restaurant["reviews"],
            "delivery_fee": delivery_rule["delivery_fee"],
            "delivery_time_rule": delivery_rule["delivery_time_label"],
            "delivery_fee_rule": delivery_rule["delivery_fee_label"],
            "eta": eta,
            "distance_km": round(distance_km, 2),
            "meal_category": item.get("meal_category") or item.get("meal_type"),
            "category_label": meal_label_vi(item.get("meal_category") or item.get("meal_type")),
            "score": round(clamp(final_score), 1),
            "match_percent": int(round(clamp(final_score))),
            "reasons": explain(scores, item, restaurant, distance_km),
            "restaurant_image_path": restaurant["image_path"],
        }
        results.append(row)
    results.sort(key=lambda x: x["score"], reverse=True)
    meta = weather_meta(weather_code, weather)
    profile.update({
        "user_lat": user_lat,
        "user_lon": user_lon,
        "budget": budget,
        "hunger": hunger,
        "time_available": time_available,
        "category_filter": category_filter,
        "category_filter_label": suggestion_filter_label(category_filter),
        "weather_code": weather_code,
        "weather_icon": form.get("weather_icon") or meta["icon"],
        "weather_label": form.get("weather_label") or meta["label"],
    })
    return results, profile


@app.template_filter("vnd")
def vnd(value: Any) -> str:
    return f"{as_int(value):,}".replace(",", ".") + " đ"


@app.route("/")
def home():
    restaurants, menu = load_data()
    return render_template("home.html", restaurant_count=len(restaurants), food_count=len(menu))


@app.route("/input", methods=["GET", "POST"])
def input_page():
    if request.method == "POST":
        session["form"] = dict(request.form)
        return redirect(url_for("results"))
    values = session.get("form", {
        "budget": 60000,
        "hunger": 6,
        "time_available": 45,
        "weather": 31,
        "health_goal": "balanced",
        "category_filter": "normal",
        "user_lat": DEFAULT_LAT,
        "user_lon": DEFAULT_LON,
    })
    return render_template("input.html", values=values)


def restaurant_recommendations(item_recommendations: List[Dict[str, Any]], limit: int = 5) -> List[Dict[str, Any]]:
    """Group fuzzy menu results by restaurant so the result screen recommends restaurants first."""
    grouped: Dict[str, Dict[str, Any]] = {}
    for item in item_recommendations:
        rid = item["restaurant_id"]
        if rid not in grouped:
            grouped[rid] = {
                "restaurant_id": rid,
                "restaurant_name": item["restaurant_name"],
                "lat": item["lat"],
                "lon": item["lon"],
                "rating": item["rating"],
                "reviews": item["reviews"],
                "delivery_fee": item["delivery_fee"],
                "distance_km": item["distance_km"],
                "eta": item["eta"],
                "restaurant_image_path": item.get("restaurant_image_path") or item.get("image_path"),
                "items": [],
            }
        grouped[rid]["items"].append(item)

    restaurants = []
    for row in grouped.values():
        items = sorted(row["items"], key=lambda x: x["score"], reverse=True)
        top3 = items[:3]
        avg_top3 = sum(i["score"] for i in top3) / max(len(top3), 1)
        best = items[0]
        rating_score = clamp((row["rating"] - 3.8) / 1.2 * 100)
        review_score = clamp(min(row["reviews"], 500) / 5)
        eta_score = clamp(100 - max(row["eta"] - 20, 0) * 2)
        distance_score = clamp(100 - max(row["distance_km"] - 1, 0) * 14)
        standard_score = rating_score * 0.65 + review_score * 0.35
        restaurant_score = (
            best["score"] * 0.60
            + avg_top3 * 0.20
            + standard_score * 0.07
            + eta_score * 0.06
            + distance_score * 0.07
        )
        row.update({
            "best_item": best,
            "top_items": top3,
            "item_count": len(items),
            "score": round(clamp(restaurant_score), 1),
            "match_percent": int(round(clamp(restaurant_score))),
            "standard_score": int(round(clamp(standard_score))),
            "is_standard": row["rating"] >= 4.3 and row["reviews"] >= 30,
            "reasons": build_restaurant_reasons(row, best),
            "items": items,
        })
        restaurants.append(row)
    restaurants.sort(key=lambda x: x["score"], reverse=True)
    for index, row in enumerate(restaurants[:limit], start=1):
        row["rank"] = index
    return restaurants[:limit]


def build_restaurant_reasons(row: Dict[str, Any], best_item: Dict[str, Any]) -> List[str]:
    reasons = []
    if row.get("is_standard"):
        reasons.append("quán đạt chuẩn")
    if row.get("distance_km", 99) <= 2:
        reasons.append("gần bạn")
    if row.get("eta", 99) <= 30:
        reasons.append("giao nhanh")
    if best_item.get("match_percent", 0) >= 80:
        reasons.append("menu hợp sở thích")
    return reasons[:4] or ["điểm tổng thể tốt"]


@app.route("/results")
def results():
    form = session.get("form")
    if not form:
        return redirect(url_for("input_page"))
    recommendations, profile = recommend(form)
    restaurants = restaurant_recommendations(recommendations, limit=5)
    return render_template("results.html", recommendations=restaurants, profile=profile)


@app.route("/restaurant/<restaurant_id>")
def restaurant_detail(restaurant_id: str):
    form = session.get("form", {})
    recommendations, profile = recommend(form)
    items = [r for r in recommendations if r["restaurant_id"] == restaurant_id]
    if not items:
        restaurants, _ = load_data()
        restaurant = next((r for r in restaurants if r["restaurant_id"] == restaurant_id), None)
        return render_template("restaurant.html", restaurant=restaurant, items=[], profile=profile)
    restaurant = items[0]
    return render_template("restaurant.html", restaurant=restaurant, items=items[:30], profile=profile)


@app.route("/cart/add/<food_id>", methods=["POST"])
def add_to_cart(food_id: str):
    form = session.get("form", {})
    recommendations, _ = recommend(form)
    item = next((r for r in recommendations if r["food_id"] == food_id), None)
    cart = session.get("cart", [])
    if item:
        cart.append({"food_id": item["food_id"], "food_name": item["food_name"], "restaurant_id": item["restaurant_id"], "restaurant_name": item["restaurant_name"], "price": item["price"], "image_path": item["image_path"], "eta": item.get("eta"), "distance_km": item.get("distance_km"), "delivery_fee": item.get("delivery_fee"), "delivery_fee_rule": item.get("delivery_fee_rule"), "delivery_time_rule": item.get("delivery_time_rule")})
        session["cart"] = cart
    return redirect(request.referrer or url_for("cart"))


@app.route("/dineout/<restaurant_id>", methods=["POST"])
def dineout(restaurant_id: str):
    form = session.get("form", {})
    recommendations, _ = recommend(form)
    item = next((r for r in recommendations if r["restaurant_id"] == restaurant_id), None)
    if item:
        session["cart"] = [{"food_id": item["food_id"], "food_name": item["food_name"], "restaurant_id": item["restaurant_id"], "restaurant_name": item["restaurant_name"], "price": item["price"], "image_path": item["image_path"], "eta": item.get("eta"), "distance_km": item.get("distance_km"), "delivery_fee": item.get("delivery_fee"), "delivery_fee_rule": item.get("delivery_fee_rule"), "delivery_time_rule": item.get("delivery_time_rule")} ]
        return redirect(url_for("cart", mode="dineout"))
    return redirect(url_for("results"))

@app.route("/cart")
def cart():
    items = session.get("cart", [])
    subtotal = sum(as_int(i["price"]) for i in items)
    delivery_fee = max([as_int(i.get("delivery_fee"), 0) for i in items], default=0)
    delivery_total = subtotal + delivery_fee
    return render_template("cart.html", items=items, total=subtotal, delivery_fee=delivery_fee, delivery_total=delivery_total)


@app.route("/checkout", methods=["POST"])
def checkout():
    cart_items = session.get("cart", [])
    if not cart_items:
        return redirect(url_for("cart"))
    subtotal = sum(as_int(i["price"]) for i in cart_items)
    order_type = request.form.get("order_type", "delivery")
    delivery_fee = max([as_int(i.get("delivery_fee"), 0) for i in cart_items], default=0) if order_type == "delivery" else 0
    total = subtotal + delivery_fee
    orders = session.get("orders", [])
    order_id = f"OD{len(orders) + 1:04d}"
    first_eta = as_int(cart_items[0].get("eta"), 30)
    order = {
        "order_id": order_id,
        "created_at": time.time(),
        "order_type": order_type,
        "restaurant_name": cart_items[0].get("restaurant_name"),
        "items": cart_items,
        "subtotal": subtotal,
        "delivery_fee": delivery_fee,
        "total": total,
        "status": "Mô phỏng đang chạy" if order_type == "delivery" else "Đã giữ chỗ",
        "eta": first_eta if order_type == "delivery" else 15,
        "steps": order_steps(order_type),
    }
    orders.insert(0, order)
    session["orders"] = orders
    session["cart"] = []
    return render_template("checkout.html", order=order)


def order_step_labels(order_type: str) -> List[str]:
    if order_type == "dineout":
        return ["Đã giữ chỗ", "Đang giữ bàn", "Bạn đang đến quán", "Hoàn tất"]
    return ["Đã nhận đơn", "Đang chuẩn bị", "Tài xế đang lấy món", "Đang giao", "Hoàn tất"]


def order_steps(order_type: str, active: int = 1) -> List[Dict[str, Any]]:
    labels = order_step_labels(order_type)
    return [{"label": label, "done": idx <= active, "active": idx == active} for idx, label in enumerate(labels, start=1)]


def compute_order_status(order: Dict[str, Any]) -> Dict[str, Any]:
    labels = order_step_labels(order.get("order_type", "delivery"))
    elapsed = max(0, int(time.time() - as_float(order.get("created_at"), time.time())))
    step_seconds = 8 if order.get("order_type") == "delivery" else 10
    active = min(len(labels), elapsed // step_seconds + 1)
    progress = int((active - 1) / max(len(labels) - 1, 1) * 100)
    if active == len(labels):
        progress = 100
    return {
        "active": active,
        "status": labels[active - 1],
        "progress": progress,
        "steps": order_steps(order.get("order_type", "delivery"), active),
    }


@app.route("/api/order_status/<order_id>")
def api_order_status(order_id: str):
    order = next((o for o in session.get("orders", []) if o.get("order_id") == order_id), None)
    if not order:
        return jsonify({"error": "not_found"}), 404
    return jsonify(compute_order_status(order))


@app.route("/orders")
def orders():
    orders_list = session.get("orders", [])
    for order in orders_list:
        order.update(compute_order_status(order))
    return render_template("orders.html", orders=orders_list)


@app.route("/reset")
def reset():
    session.clear()
    return redirect(url_for("home"))


if __name__ == "__main__":
    app.run(debug=True)

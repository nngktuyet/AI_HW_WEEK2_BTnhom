# FoodMood V15 Patch Notes

## Main fixes

1. **Meal scoring fixed**
   - `preferred_meal` is now treated as a categorical output.
   - Price and distance still use centroid defuzzification.
   - Meal matching now uses direct rule activation strength from `profile['rule_strengths']['meal']`.
   - This prevents drinks/desserts from being recommended only because a centroid lands near their numeric area.

2. **Practical hunger guardrails added**
   - If hunger is high (`>= 8`), drinks/desserts/snacks are capped so they do not dominate recommendations.
   - If hunger is light (`<= 3`), heavy meals and fast food are capped.

3. **Balanced health goal softened**
   - `balanced` no longer automatically pushes strongly toward `healthy`.
   - `balanced + hungry/starving` now supports `fullmeal` more clearly.

4. **Budget guardrail added**
   - Items above 150% of user budget are removed.
   - Items above 120% of user budget are kept but receive a lower price match.

5. **Restaurant ranking adjusted**
   - Fuzzy item score is now more important.
   - Rating/review quality is reduced to a smaller tie-breaker.

6. **Code cleanup**
   - Removed duplicate `mamdani_centroid()` definition.

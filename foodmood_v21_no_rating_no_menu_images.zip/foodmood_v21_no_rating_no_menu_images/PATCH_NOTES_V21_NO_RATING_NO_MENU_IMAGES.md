# Patch notes V21

Changes made:

1. Removed restaurant rating/review display from UI:
   - `templates/results.html`
   - `templates/restaurant.html`

2. Removed food images from the menu list shown after opening a restaurant:
   - `templates/restaurant.html`
   - Added `.menu-item-no-image` CSS in `static/css/style.css`

3. Removed rating wording from internal explanation strings in `app.py` so the UI/report text will not mention rating as a visible reason.

No fuzzy rules, delivery fee, map, cart, or checkout logic were changed.

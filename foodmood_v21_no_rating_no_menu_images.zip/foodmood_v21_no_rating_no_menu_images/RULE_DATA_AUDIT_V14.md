# V14 audit

## UI
- Đổi nhãn `Chế độ gợi ý` thành `Chế độ`.
- Căn giữa nhóm `Mục tiêu sức khỏe` và nhóm `Chế độ`.
- `Mục tiêu sức khỏe` chỉ còn 3 lựa chọn: `diet`, `balanced`, `bulking`.
- `Chế độ` chỉ còn 2 lựa chọn: `normal`, `vegetarian`.
- Không có cuisine và không có spicy/ăn cay trong form hoặc logic lọc.

## Weather
- UI không cho người dùng nhập weather thủ công.
- JavaScript lấy GPS và gọi Open-Meteo API.
- Nhiệt độ API được ghi vào hidden input `weather` để đưa vào fuzzy rule.
- Weather code API chỉ dùng để hiển thị icon/trạng thái; fuzzy rule vẫn nhận đúng biến `weather` là nhiệt độ, như `rules-1.ipynb`.

## Rule
- Fuzzy variables, membership functions và 101 rules giữ theo `rules-1.ipynb`.
- Health goal mapping theo universe 1-10 trong notebook:
  - Giảm cân -> 2
  - Cân bằng -> 4
  - Tăng cơ -> 8
- Không đưa cuisine/spicy vào fuzzy rule.

## Data
- Dataset được giữ theo `AI_dataset_HW_week2 (2).xlsx`:
  - Quán: 68 dòng
  - Menu: 344 dòng
  - Food-id, tên món và giá món được giữ đúng theo sheet Menu.
